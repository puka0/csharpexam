list = list(input())
print(list[1])
for item in list:
    print(item)