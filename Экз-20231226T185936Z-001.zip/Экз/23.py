list = []
while True:
    item = input()
    if item != "exit":
        list.append(item)
    else:
        break
print(list)